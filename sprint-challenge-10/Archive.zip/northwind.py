'''
ANSWER: 10 most expensive items per unit price
1. Cote de Blaye
2. Thuringer Rostbratwurst
3. Mishi Kobe Niku
4. Sir Rodney's Marmalade
5. Carnarvon Tigers
6. Raclette Courdavault
7. Manjimup Dried Apples
8. Tarte au sucre
9. Ipoh Coffee
10. Rossle Sauerkraut
'''

'''
ANSWER average age of employee at time of hiring: 37.2 years old
'''

'''
ANSWER 10 most expensive items and suppliers
1. Cote de Blaye - Aux joyeux ecclesiastiques
2. Thuringer Rostbratwurst - Plutzer Legensmittelgrosmarkte AG
3. Mishi Kobe Niku - Tokyo Traders
4. Sir Rodney's Marmalade - Specialty Bisquits, Ltd.
5. Carnarvon Tigers - Pavlova, Ltd.
6. Raclette Courdavault - Gai paturage
7. Manjimup Dried Apples - G'day, Mate
8. Tarte au sucre - Forets d'erables
9. Ipoh Coffee - Leka Trading
10. Rossle Sauerkraut - Plutzer Lebensmittelgrosmarkte AG
'''

'''
ANSWER largest category by unique products in it: Condiments
'''

#!/usr/env/bin Python
import sqlite3

# Open connection to new blank database file
conn = sqlite3.connect('northwind_small.sqlite3')
curs = conn.cursor()

# 10 most expensive items
curs.execute('SELECT ProductName FROM Product ORDER BY UnitPrice DESC LIMIT 10;')
print(f'10 most expensive: {curs.fetchall()}')

# Average age of employee at time of hiring
curs.execute('SELECT AVG(HireDate - BirthDate) FROM Employee;')
print(f'Average age at time of hiring: {curs.fetchall()[0][0]}')

# (Stretch) average age of employee at hire by city

# 10 most expensive items and their suppliers
curs.execute('SELECT ProductName, CompanyName FROM Product JOIN Supplier ON Product.SupplierId = Supplier.Id ORDER BY UnitPrice DESC LIMIT 10;')
print(f'10 most expensive with suppliers: {curs.fetchall()}')

# Largest category by unique number of products in it
largest_category = '''
SELECT CategoryName
FROM Category
JOIN Product
ON Category.Id = Product.CategoryId
ORDER BY
(SELECT DISTINCT Product.id)
DESC
LIMIT 1;
'''
curs.execute(largest_category)
print(f'Largest category by unique products: {curs.fetchall()[0][0]}')